﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game {
    Player player;
    Parser parser;
    bool playing;
    Room exit;

    public Game(GameOutput gameIO)
    {
        playing = false;
        parser = new Parser(new CommandWords());
        player = new Player(GameWorld.instance.Entrance, gameIO);
        exit = GameWorld.instance.Exit;
        Player.playerEnteredRoom += playerEnteredRoom; //subscribe to the player when player broadcasts an action
    }

    private void playerEnteredRoom(Room room)//observer ->player
    {
        if(room == exit)
        {
        
            player.outputMessage("\nYou reached the exit!"); //display to the console that the user made it to the exit
            this.end();
        }
    }

    /*
    public Room createWorld()
    {
       

       // return outside;
    }*/

    public void start()
    {
        playing = true;
        player.outputMessage(welcome());
    }

    public void end()
    {
        playing = false;
        player.outputMessage(goodbye());
        
    }

    public string welcome()
    {
        return " Radio: '*kshh*  ... Come in *kshhhhhh* .. Anyone still alive? *kshh*' " +
               "[ your ship was hit by a graviton cannon and is drifting in space ] \n " +
               " Robot: 'Beeeep, starting repair process. Beep, Life support systems engaged'  " +
               "[ one lone robot saves you and your ship from certain doom ] \n\n" +
               "[ a day later you are no longer in critical condition and your ship is no longer adrift ]"+
               "You set out to hunt down the person who did this to you" + player.currentRoom.description() ;
       
    }

    public string goodbye()
    {
        return "\n Understandable, Have a nice day \n";
    }

    public bool execute(string commandString)
    {
        bool finished = false;
       
        if (playing)//only execute a command when user is still playing
        {
            player.outputMessage("\n>" + commandString);
            Command command = parser.parseCommand(commandString); //using parser class, instantiate correct Command from user input
            if (command != null)
            {
                finished = command.execute(player); //using inhertience, calls the corresponding command

                if(finished == true)//if the quit command is executed, quit application
                {
                    this.end();
                }
            }
            else
            {
                player.outputMessage("\nI don't understand what you mean by '<b>" + commandString + "</b>'");
            }
        }
        return finished;
    }
}
