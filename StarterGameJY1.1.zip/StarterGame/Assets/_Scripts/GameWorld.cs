﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct roomStructure
{
    public Room entrance;
    public Room exit;
}

public class GameWorld
{
    private static GameWorld _instance = null; //null until instantiated, can only be instantiated once
    public static GameWorld instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new GameWorld();
            }
            return _instance;
        }
    }

    public Room Entrance
    {
        get
        {
            return entrance;
        }

        set
        {
            entrance = value;
        }
    }

    public Room Exit
    {
        get
        {
            return exit;
        }

        set
        {
            exit = value;
        }
    }

    private Room entrance;
    private Room exit;


    
    private GameWorld()
    {
        roomStructure rooms = createWorld();
        entrance = rooms.entrance;
        Exit = rooms.exit;
        //Player.playerEnteredRoom += playerEnteredRoom; //subscribe to the player when player broadcasts an action
    }

    /*
    public void playerEnteredRoom(Room room)
    {
        Debug.Log("this is hapenning in gameworld");
        if (room == Exit)
        {
            
        }
    }*/

    private roomStructure createWorld()
    {
        //Descriptions for planets below. D is spaceship
        string deafultDescA = "";
        string deafultDesB = "";
        string deafultDescC = "";
        string deafultDescD = "";




        Room SpaceShip = new Room("This is your spaceship. It has seen much action in its time, still has some left too");


        Room a1 = new Room("Water Planet Space Port");
        Room a2 = new Room();
        Room a3 = new Room();
        Room a4 = new Room();
        Room a5 = new Room();
        Room a6 = new Room();
        Room a7 = new Room();

        Room b1 = new Room();
        Room b2 = new Room();
        Room b3 = new Room();
        Room b4 = new Room();
        Room b5 = new Room();
        Room b6 = new Room();

        Room c1 = new Room();
        Room c2 = new Room();
        Room c3 = new Room();
        Room c4 = new Room();
        Room c5 = new Room();
        Room c6 = new Room();

        //Space Ship
        SpaceShip.setExit("west", a1);
        SpaceShip.setExit("north", b1);
        SpaceShip.setExit("east", c1);
        // Water planet links
        a1.setExit("west", a2);
        a1.setExit("east", SpaceShip);
        a2.setExit("west", a3);
        a2.setExit("north", a6);
        a2.setExit("east", a1);
        a2.setExit("south", a7);
        a3.setExit("west", a4);
        a3.setExit("east", a2);
        a4.setExit("west", a5);
        a4.setExit("west", a3);



        /*
        Room outside = new Room("outside the main entrance of the university");
        Room cctparking = new Room("in the parking lot at CCT");
        Room boulevard = new Room("on the boulevard");
        Room universityParking = new Room("in the parking lot at University Hall");
        Room parkingDeck = new Room("in the parking deck");
        Room cct = new Room("in the CCT building");
        Room theGreen = new Room("in the green in from of Schuster Center");
        Room universityHall = new Room("in University Hall");
        Room schuster = new Room("in the Schuster Center");

        outside.setExit("west", boulevard);

        //Exits for boulevard
        boulevard.setExit("east", outside);
        boulevard.setExit("south", cctparking);
        boulevard.setExit("west", theGreen);
        boulevard.setExit("north", universityParking);

        //Exits for CCT parking
        cctparking.setExit("west", cct);
        cctparking.setExit("north", boulevard);

        //Exits for CCT
        cct.setExit("east", cctparking);
        cct.setExit("north", schuster);

        //exits for Schuster
        schuster.setExit("south", cct);
        schuster.setExit("north", universityHall);
        schuster.setExit("east", theGreen);

        //exits for theGreen
        theGreen.setExit("west", schuster);
        theGreen.setExit("east", boulevard);

        //Exits for Univserity hall
        universityHall.setExit("south", schuster);
        universityHall.setExit("east", universityParking);

        //Exits for university parking
        universityParking.setExit("south", boulevard);
        universityParking.setExit("west", universityHall);
        universityParking.setExit("north", parkingDeck);

        //Exits for parkingdeck
        parkingDeck.setExit("south", universityParking);
        */

        roomStructure output;
        output.entrance = SpaceShip;
        output.exit = a5;
        Entrance = SpaceShip;
        return output;
    }
}