﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item {
    private string name;
    public string Name
    {
        get
        {
            return this.name;
        }
    }
    private int itemWeight;
    public int ItemWeight
    {
        get
        {
            return this.itemWeight;
        }
    }

    public Item() : this("deafult_item")
    {

    }
    public Item(string name) : this(name, 1)
    {

    }
    public Item(string name, int weight)
    {
        this.name = name;
        this.itemWeight = weight;
    }
}
