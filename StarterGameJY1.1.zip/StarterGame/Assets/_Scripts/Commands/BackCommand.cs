﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackCommand : Command
{
    private Room[] roomsVisted;
    public BackCommand()
    {
        this.name = "back";
        this.roomsVisted = new Room[11];
        Player.playerEnteredRoom += playerEnteredRoom; //subscribe to the player when player broadcasts an action
    }

    /**
     *executes the command entered by the user after it is parsed
     * 
     * @param player object which performed the command
     * @return boolean used for logic elsewhere
     */
    public override bool execute(Player player)
    {
        Room prevRoom = pop();
        if (prevRoom != null)
        {
            player.currentRoom = prevRoom;
            player.outputMessage(prevRoom.description());
        }
        else
        {
            player.outputMessage("\nI cannot preform that command!\n");
        }

        return false;
    }

    /**
     * Observer Method waits for PlayerEnteredRoom call and adds the room into the roomsVisted array using helper method 'addFirst()'
     * 
     * @param room object of the room entered
     */
    public void playerEnteredRoom(Room room)
    {
        roomsVisted = addFirst(room);
    }

    /**
     * Helper method for class returns first element in array and shifts remaining elements
     */
    private Room pop()
    {
        
        Debug.Log(print());
        Room returnRef = roomsVisted[1];
        
        for(int i = 2; i < roomsVisted.Length; i++)
        {
            roomsVisted[i - 1] = roomsVisted[i];       
        }
        return returnRef;
    }

    private Room[] addFirst(Room ele)
    {
        Room[] temp = new Room[roomsVisted.Length];
        for(int i = 0; i < roomsVisted.Length; i++)
        {
            if(i == 0)
            {
                temp[i] = ele;
            }
            else
            {
                temp[i] = roomsVisted[i - 1];
            }
        }
        return temp;
    }

    private string print()
    {
        string strReturn = "";
        foreach (Room ele in roomsVisted)
        {
            if(ele != null)
            {
                strReturn += ele.tag + "\n";
            }
            else
            {
                strReturn += " \n";
            }
            
        }
        return strReturn;
    }
}
