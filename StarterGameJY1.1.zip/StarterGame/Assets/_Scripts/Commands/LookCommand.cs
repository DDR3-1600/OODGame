﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookCommand : Command
{
    public LookCommand()
    {
        this.name = "look";
    }

    public override bool execute(Player player)
    {
        player.lookAround(player.currentRoom.tag);
        return false;
    }
    
}
