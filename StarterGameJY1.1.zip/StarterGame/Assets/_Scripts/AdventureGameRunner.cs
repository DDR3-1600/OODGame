﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AdventureGameRunner : MonoBehaviour {
    public Text output;
    public RectTransform rt;
    public Text input;
    public InputField inputField;
    private GameOutput gameIO;
    private Game game;

    // Use this for initialization
    public void Start () {

        gameIO = new GameOutput(output);
        game = new Game(gameIO);
        gameIO.clear();
        game.start();
        inputField.ActivateInputField();
	}

    public void Update()
    {
        
    }

    public void sendCommand()
    {
        if(input.text.Length > 0)
        {
            game.execute(input.text); //where the user input is sent
            rt.localPosition = new Vector3(rt.localPosition.x, rt.rect.height, rt.localPosition.z);
            inputField.text = "";
            inputField.ActivateInputField();
        }
    }
}
