﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Player {
    public static event Action<Room>playerEnteredRoom; //this makes player the observed
    

    private Room _currentRoom = null;
    public Room currentRoom
    {
        get
        {
            return _currentRoom;
        }
        set
        {
            _currentRoom = value;
        }
    }

    private Room previousRoom;
    public Room PreviousRoom
    {
        get
        {
            return previousRoom;
        }

        set
        {
            previousRoom = value;
        }
    }

    private GameOutput _io = null;

    public Player(Room room, GameOutput output)
    {
        _currentRoom = room;
        _io = output;
    }

    public void waltTo(string direction)
    {
        Room nextRoom = this._currentRoom.getExit(direction);
        if( nextRoom != null)
        {
            this.previousRoom = this._currentRoom;
            this._currentRoom = nextRoom;
            if(playerEnteredRoom != null)
            {
                playerEnteredRoom(this.currentRoom);
            }
            if(GameWorld.instance.Exit != this.currentRoom)
            {
                this.outputMessage("\n" + this._currentRoom.description());
            }
           
        } else
        {
            this.outputMessage("\nThere is no door on " + direction);
        }
    }

    public void lookAround(string roomDesc)
    { 
        this.outputMessage("\n " + roomDesc);
    }

    public void outputMessage(string message)
    {
        _io.sendLine(message);
    }
}
